* npm install -g cordova

* npm install ios-sim

* cordova platform add ios

* cordova plugin add cordova-plugin-inappbrowser

* cordova plugin add cordova-plugin-customurlscheme --variable URL_SCHEME=com.oauthinaction.mynativeapp

* cordova run ios  
